// ============================================================
// AIV Application - Dashboard Table Visualization Automation
// Framework: Playwright (Node.js)
// Test File: aiv_dashboard_table_viz.spec.js
// Description: End-to-end test for creating a Table Visualization
//   on the Dashboard: Login → Dashboard → Create Viz → Table Widget
//   → Dataset Selection → Column Selection → Save → Preview
// ============================================================

const { test, expect } = require('@playwright/test');
const path = require('path');
const fs = require('fs');

// ── Screenshot Directory ─────────────────────────────────────
const SCREENSHOT_DIR = path.join(__dirname, 'screenshots_table_viz');
if (!fs.existsSync(SCREENSHOT_DIR)) fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });

let stepIndex = 0;
async function capture(page, label, status = 'info') {
  stepIndex++;
  const pad    = String(stepIndex).padStart(2, '0');
  const slug   = label.replace(/\s+/g, '_').replace(/[^\w_]/g, '').toLowerCase();
  const fname  = `${pad}_${status}_${slug}.png`;
  const fpath  = path.join(SCREENSHOT_DIR, fname);
  await page.screenshot({ path: fpath, fullPage: true });
  console.log(`  📸 [${status.toUpperCase()}] ${fname}`);
  return fpath;
}

function log(emoji, msg) { console.log(`${emoji}  ${msg}`); }

// ── Playwright Config ────────────────────────────────────────
test.use({
  headless: false,
  slowMo: 600,
  viewport: { width: 1440, height: 900 },
  video: 'on',
  screenshot: 'only-on-failure',
});

// ════════════════════════════════════════════════════════════
//  MAIN TEST
// ════════════════════════════════════════════════════════════
test.describe('AIV — Dashboard Table Visualization', () => {

  test('Login → Dashboard → Create Viz → Table Widget → Dataset → All Columns → Save → Preview', async ({ page }) => {

    // ──────────────────────────────────────────────────────
    // STEP 1  Navigate to Application
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 1 — Navigate to Application');
    console.log('══════════════════════════════════════════════');
    try {
      await page.goto('http://localhost:8080/aiv/', {
        waitUntil: 'networkidle',
        timeout: 30000,
      });
      log('✅', 'Application loaded');
      await capture(page, 'application loaded', 'success');
    } catch (err) {
      await capture(page, 'application load failed', 'error');
      log('❌', `Application load failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 2  Login
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 2 — Login');
    console.log('══════════════════════════════════════════════');
    try {
      // Wait for login form
      await page.waitForSelector(
        'input[type="email"], input[name="email"], input[placeholder*="email" i], input[placeholder*="username" i], input[type="text"]',
        { timeout: 15000 }
      );
      await capture(page, 'login page visible', 'success');

      // Fill email / username
      const emailField = page.locator(
        'input[type="email"], input[name="email"], input[placeholder*="email" i], input[placeholder*="username" i], input[type="text"]'
      ).first();
      await emailField.clear();
      await emailField.fill('Admin');
      log('✅', 'Email field filled — "Admin"');

      // Fill password
      const passField = page.locator(
        'input[type="password"], input[name="password"], input[placeholder*="password" i]'
      ).first();
      await passField.clear();
      await passField.fill('password');
      log('✅', 'Password field filled');

      await capture(page, 'credentials filled', 'info');

      // Submit
      const loginBtn = page.locator(
        'button[type="submit"], button:has-text("Login"), button:has-text("Sign in"), input[type="submit"]'
      ).first();
      await loginBtn.click();

      await page.waitForLoadState('networkidle', { timeout: 25000 });
      log('✅', 'Login submitted — waiting for dashboard');
      await capture(page, 'login success dashboard loaded', 'success');
    } catch (err) {
      await capture(page, 'login failed', 'error');
      log('❌', `Login failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 3  Hamburger Menu
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 3 — Click Hamburger Menu (Top Left)');
    console.log('══════════════════════════════════════════════');
    try {
      await page.waitForTimeout(2000);

      const hamburgerSelectors = [
        '.hamburger',
        '.hamburger-menu',
        '.menu-toggle',
        '[class*="hamburger"]',
        '[class*="sidebar-toggle"]',
        '[class*="menu-toggle"]',
        'button[aria-label*="menu" i]',
        'button[aria-label*="toggle" i]',
        '.navbar-toggler',
        'i.fa-bars',
        'i.bi-list',
        '[class*="nav-toggle"]',
        'button.toggle',
      ];

      let clicked = false;
      for (const sel of hamburgerSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 1500 }).catch(() => false)) {
          await el.click();
          clicked = true;
          log('✅', `Hamburger clicked — selector: ${sel}`);
          break;
        }
      }

      if (!clicked) {
        await page.mouse.click(28, 28);
        log('⚠️', 'Hamburger clicked via coordinate fallback (28, 28)');
      }

      await page.waitForTimeout(1000);
      await capture(page, 'hamburger menu opened', 'success');
    } catch (err) {
      await capture(page, 'hamburger menu failed', 'error');
      log('❌', `Hamburger failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 4  Click Dashboard
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 4 — Navigate to Dashboard');
    console.log('══════════════════════════════════════════════');
    try {
      const dashboardSelectors = [
        'text=Dashboard',
        'a:has-text("Dashboard")',
        'li:has-text("Dashboard")',
        'span:has-text("Dashboard")',
        '[href*="dashboard" i]',
        '[class*="dashboard"]',
      ];

      let navClicked = false;
      for (const sel of dashboardSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 3000 }).catch(() => false)) {
          await el.click();
          navClicked = true;
          log('✅', `Dashboard nav clicked — selector: ${sel}`);
          break;
        }
      }

      if (!navClicked) {
        await capture(page, 'dashboard nav not found', 'error');
        throw new Error('Dashboard navigation item not found');
      }

      await page.waitForLoadState('networkidle', { timeout: 20000 });
      await page.waitForTimeout(1500);
      await capture(page, 'dashboard section opened', 'success');
    } catch (err) {
      await capture(page, 'dashboard navigation failed', 'error');
      log('❌', `Dashboard navigation failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 5  Click "+" / Create New Viz
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 5 — Click "+" to Create New Visualization');
    console.log('══════════════════════════════════════════════');
    try {
      const plusSelectors = [
        'button:has-text("+")',
        'a:has-text("+")',
        '[title="+"]',
        '[aria-label*="add" i]',
        '[aria-label*="new" i]',
        '[aria-label*="create" i]',
        'button.add-btn',
        'button.create-btn',
        '.btn-add',
        '.icon-add',
        'i.fa-plus',
        'i.bi-plus',
        '[class*="add-new"]',
        '[class*="create-new"]',
        'button[class*="plus"]',
        'span:has-text("+")',
      ];

      let plusClicked = false;
      for (const sel of plusSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 2000 }).catch(() => false)) {
          await el.click();
          plusClicked = true;
          log('✅', `"+" button clicked — selector: ${sel}`);
          break;
        }
      }

      if (!plusClicked) {
        await capture(page, 'plus button not found', 'error');
        throw new Error('"+" / Create button not found on Dashboard');
      }

      await page.waitForTimeout(1500);
      await capture(page, 'create viz dialog opened', 'success');
    } catch (err) {
      await capture(page, 'plus button failed', 'error');
      log('❌', `"+" click failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 6  Enter Viz Name
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 6 — Enter Visualization Name');
    console.log('══════════════════════════════════════════════');
    const VIZ_NAME = 'Test viz on Automation';
    try {
      // Locate the Name input inside the dialog
      const nameInputSelectors = [
        'input[name="name"]',
        'input[placeholder*="name" i]',
        'input[placeholder*="title" i]',
        'input[aria-label*="name" i]',
        'input[id*="name" i]',
        '.modal input[type="text"]',
        '[class*="dialog"] input[type="text"]',
        '[role="dialog"] input[type="text"]',
        'dialog input[type="text"]',
        'input.form-control',
      ];

      let nameInput = null;
      for (const sel of nameInputSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 3000 }).catch(() => false)) {
          nameInput = el;
          log('✅', `Name input found — selector: ${sel}`);
          break;
        }
      }

      if (!nameInput) {
        await capture(page, 'name input not found', 'error');
        throw new Error('Visualization name input field not found');
      }

      await nameInput.clear();
      await nameInput.fill(VIZ_NAME);
      log('✅', `Viz name entered: "${VIZ_NAME}"`);

      await capture(page, 'viz name entered', 'info');
    } catch (err) {
      await capture(page, 'viz name input failed', 'error');
      log('❌', `Viz name input failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 7  Click "Create File" Button
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 7 — Click "Create File" Button');
    console.log('══════════════════════════════════════════════');
    try {
      const createFileSelectors = [
        'button:has-text("Create File")',
        'button:has-text("Create file")',
        'button:has-text("Create")',
        'button:has-text("Submit")',
        'button:has-text("Save")',
        'button[type="submit"]',
        '.modal button.btn-primary',
        '[class*="dialog"] button.btn-primary',
        '[role="dialog"] button[type="submit"]',
        'input[type="submit"][value*="create" i]',
      ];

      let createClicked = false;
      for (const sel of createFileSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 2000 }).catch(() => false)) {
          await el.click();
          createClicked = true;
          log('✅', `"Create File" button clicked — selector: ${sel}`);
          break;
        }
      }

      if (!createClicked) {
        await capture(page, 'create file button not found', 'error');
        throw new Error('"Create File" button not found');
      }

      await page.waitForTimeout(2000);

      // Check for success toast / message
      const successMsg = await page.locator(
        'text=successfully, text=created, .toast-success, .alert-success, [class*="success"]'
      ).first().isVisible({ timeout: 5000 }).catch(() => false);

      if (successMsg) {
        log('✅', 'SUCCESS: Viz created successfully message appeared');
        await capture(page, 'viz created success message', 'success');
      } else {
        log('⚠️', 'Success toast not detected — checking if editor opened');
        await capture(page, 'after create file click', 'info');
      }

      await page.waitForLoadState('networkidle', { timeout: 20000 });
    } catch (err) {
      await capture(page, 'create file failed', 'error');
      log('❌', `"Create File" failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 8  Verify Viz Editor Opened
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 8 — Viz Editor Loaded');
    console.log('══════════════════════════════════════════════');
    try {
      await page.waitForTimeout(2000);

      // Confirm we're in the viz editor by checking for widgets panel
      const editorIndicators = [
        '[class*="widget"]',
        '[class*="panel"]',
        '[class*="editor"]',
        '[class*="canvas"]',
        'text=Table',
        'text=Chart',
        'text=Widgets',
      ];

      let editorOpen = false;
      for (const sel of editorIndicators) {
        if (await page.locator(sel).first().isVisible({ timeout: 3000 }).catch(() => false)) {
          editorOpen = true;
          log('✅', `Viz editor detected — indicator: ${sel}`);
          break;
        }
      }

      if (!editorOpen) {
        log('⚠️', 'Viz editor indicators not detected — screenshot taken');
      }

      await capture(page, 'viz editor opened with widgets panel', 'success');
    } catch (err) {
      await capture(page, 'viz editor check failed', 'error');
      log('❌', `Viz editor verification failed: ${err.message}`);
    }

    // ──────────────────────────────────────────────────────
    // STEP 9  Click "Table" Widget
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 9 — Select "Table" Widget');
    console.log('══════════════════════════════════════════════');
    try {
      const tableWidgetSelectors = [
        '[class*="widget"]:has-text("Table")',
        '.widget-item:has-text("Table")',
        '[title="Table"]',
        '[data-widget="table"]',
        '[data-type="table"]',
        'li:has-text("Table")',
        'div:has-text("Table"):has([class*="widget"])',
        'span:has-text("Table")',
        'button:has-text("Table")',
        'a:has-text("Table")',
        '[class*="table-widget"]',
        '[class*="widget-table"]',
        'img[alt*="table" i]',
        'text=Table',
      ];

      let tableClicked = false;
      for (const sel of tableWidgetSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 3000 }).catch(() => false)) {
          await el.click();
          tableClicked = true;
          log('✅', `Table widget clicked — selector: ${sel}`);
          break;
        }
      }

      if (!tableClicked) {
        await capture(page, 'table widget not found', 'error');
        throw new Error('Table widget not found in the widgets panel');
      }

      await page.waitForTimeout(2000);
      await capture(page, 'table widget selected added to canvas', 'success');
    } catch (err) {
      await capture(page, 'table widget selection failed', 'error');
      log('❌', `Table widget selection failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 10  Click Home / Default in Properties Panel
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 10 — Click Home Icon → General Properties');
    console.log('══════════════════════════════════════════════');
    try {
      const homeSelectors = [
        '[class*="properties"] [class*="home"]',
        '[class*="properties"] i.fa-home',
        '[class*="properties"] .bi-house',
        '[class*="sidebar-right"] [class*="home"]',
        '[aria-label*="home" i]',
        '[title*="home" i]',
        '[title*="default" i]',
        '[title*="general" i]',
        'i.fa-home',
        '.home-icon',
        '[class*="home-btn"]',
        'button[class*="home"]',
      ];

      let homeClicked = false;
      for (const sel of homeSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 3000 }).catch(() => false)) {
          await el.click();
          homeClicked = true;
          log('✅', `Home / Default icon clicked — selector: ${sel}`);
          break;
        }
      }

      if (!homeClicked) {
        log('⚠️', 'Home icon not found, may already be on General Properties');
      }

      await page.waitForTimeout(1000);
      await capture(page, 'general properties section visible', 'success');
    } catch (err) {
      await capture(page, 'home icon click failed', 'error');
      log('❌', `Home icon click failed: ${err.message}`);
    }

    // ──────────────────────────────────────────────────────
    // STEP 11  Navigate to Datasets Section
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 11 — Go to Datasets Section');
    console.log('══════════════════════════════════════════════');
    try {
      const datasetTabSelectors = [
        'text=Datasets',
        'text=Dataset',
        'a:has-text("Datasets")',
        '[class*="dataset-tab"]',
        '[href*="dataset" i]',
        'li:has-text("Dataset")',
        'button:has-text("Dataset")',
        '[aria-label*="dataset" i]',
        '[title*="dataset" i]',
      ];

      let dsClicked = false;
      for (const sel of datasetTabSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 3000 }).catch(() => false)) {
          await el.click();
          dsClicked = true;
          log('✅', `Datasets tab clicked — selector: ${sel}`);
          break;
        }
      }

      if (!dsClicked) {
        log('⚠️', 'Datasets tab not found — may already be visible');
      }

      await page.waitForTimeout(1000);
      await capture(page, 'datasets section open', 'success');
    } catch (err) {
      await capture(page, 'datasets section failed', 'error');
      log('❌', `Datasets section navigation failed: ${err.message}`);
    }

    // ──────────────────────────────────────────────────────
    // STEP 12  Search for "global_cities_dataset"
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 12 — Search Dataset: global_cities_dataset');
    console.log('══════════════════════════════════════════════');
    try {
      const searchSelectors = [
        'input[placeholder*="search" i]',
        'input[type="search"]',
        '[class*="search"] input',
        '[class*="dataset"] input',
        'input[name*="search" i]',
        '.search-input',
        'input[aria-label*="search" i]',
      ];

      let searchInput = null;
      for (const sel of searchSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 3000 }).catch(() => false)) {
          searchInput = el;
          log('✅', `Search input found — selector: ${sel}`);
          break;
        }
      }

      if (searchInput) {
        await searchInput.clear();
        await searchInput.fill('global_cities_dataset');
        log('✅', 'Typed "global_cities_dataset" in search');
        await page.waitForTimeout(1500);
        await capture(page, 'dataset search results shown', 'info');
      } else {
        log('⚠️', 'Search input not found — trying direct selection from dropdown');
        await capture(page, 'no search input using dropdown', 'info');
      }
    } catch (err) {
      await capture(page, 'dataset search failed', 'error');
      log('❌', `Dataset search failed: ${err.message}`);
    }

    // ──────────────────────────────────────────────────────
    // STEP 13  Select "global_cities_dataset"
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 13 — Select global_cities_dataset');
    console.log('══════════════════════════════════════════════');
    try {
      const datasetItemSelectors = [
        'text=global_cities_dataset',
        'li:has-text("global_cities_dataset")',
        '[data-value*="global_cities"]',
        'option:has-text("global_cities_dataset")',
        '[class*="dataset-item"]:has-text("global_cities")',
        '.select2-results__option:has-text("global_cities")',
        '[class*="list-item"]:has-text("global_cities")',
      ];

      let dsSelected = false;
      for (const sel of datasetItemSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 5000 }).catch(() => false)) {
          await el.click();
          dsSelected = true;
          log('✅', `Dataset selected — selector: ${sel}`);
          break;
        }
      }

      if (!dsSelected) {
        // Try select element
        const selectEl = page.locator('select').first();
        if (await selectEl.isVisible({ timeout: 3000 }).catch(() => false)) {
          await selectEl.selectOption({ label: 'global_cities_dataset' });
          dsSelected = true;
          log('✅', 'Dataset selected via <select> element');
        }
      }

      if (!dsSelected) {
        await capture(page, 'dataset not found in list', 'error');
        throw new Error('"global_cities_dataset" not found in dataset list');
      }

      await page.waitForTimeout(2000);
      await capture(page, 'global cities dataset selected columns visible', 'success');
    } catch (err) {
      await capture(page, 'dataset selection failed', 'error');
      log('❌', `Dataset selection failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 14  Enable All Columns via Checkbox
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 14 — Select All Columns (Checkbox)');
    console.log('══════════════════════════════════════════════');
    try {
      // Try "Select All" checkbox first
      const selectAllSelectors = [
        'input[type="checkbox"][id*="all" i]',
        'input[type="checkbox"][name*="all" i]',
        'input[type="checkbox"][aria-label*="all" i]',
        'th input[type="checkbox"]',
        '[class*="select-all"] input[type="checkbox"]',
        'label:has-text("Select All") input',
        'label:has-text("All") input',
        'input[type="checkbox"].select-all',
        '[class*="check-all"]',
      ];

      let allChecked = false;
      for (const sel of selectAllSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 2000 }).catch(() => false)) {
          const checked = await el.isChecked();
          if (!checked) await el.check();
          allChecked = true;
          log('✅', `"Select All" checkbox checked — selector: ${sel}`);
          break;
        }
      }

      if (!allChecked) {
        // Fallback: check each individual column checkbox
        log('⚠️', '"Select All" not found — checking individual column checkboxes');
        const colCheckboxes = page.locator(
          '[class*="column"] input[type="checkbox"], [class*="available"] input[type="checkbox"], [class*="field"] input[type="checkbox"]'
        );
        const count = await colCheckboxes.count();
        log('ℹ️', `Found ${count} column checkboxes`);

        for (let i = 0; i < count; i++) {
          const cb = colCheckboxes.nth(i);
          if (await cb.isVisible({ timeout: 500 }).catch(() => false)) {
            const checked = await cb.isChecked().catch(() => false);
            if (!checked) await cb.check();
          }
        }
        log('✅', `Checked all ${count} column checkboxes individually`);
      }

      await page.waitForTimeout(2000);
      await capture(page, 'all columns selected visible in table viz', 'success');
    } catch (err) {
      await capture(page, 'column selection failed', 'error');
      log('❌', `Column selection failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 15  Click Save (Blue Save Icon)
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 15 — Save the Work (Blue Save Icon)');
    console.log('══════════════════════════════════════════════');
    try {
      const saveSelectors = [
        'button[title*="save" i]',
        'button[aria-label*="save" i]',
        '[class*="save-btn"]',
        '[class*="btn-save"]',
        'button:has-text("Save")',
        'i.fa-save',
        '[class*="save-icon"]',
        'button.save',
        '[title="Save"]',
        '[title="save"]',
        'svg[class*="save"]',
        'a:has-text("Save")',
      ];

      let saveClicked = false;
      let saveAttempts = 0;
      const maxSaveAttempts = 3;

      // Click save up to 3 times until confirmation is seen
      while (saveAttempts < maxSaveAttempts) {
        saveAttempts++;
        log('ℹ️', `Save attempt ${saveAttempts} of ${maxSaveAttempts}`);

        if (!saveClicked) {
          for (const sel of saveSelectors) {
            const el = page.locator(sel).first();
            if (await el.isVisible({ timeout: 2000 }).catch(() => false)) {
              await el.click();
              saveClicked = true;
              log('✅', `Save button clicked — selector: ${sel}`);
              break;
            }
          }
        } else {
          // Re-click if known
          const el = page.locator(saveSelectors[0]).first();
          if (await el.isVisible({ timeout: 1000 }).catch(() => false)) await el.click();
        }

        await page.waitForTimeout(1500);

        // Check for save confirmation
        const savedIndicators = [
          'text=saved',
          'text=Saved',
          'text=success',
          '.toast-success',
          '.alert-success',
          '[class*="saved"]',
          '[class*="success"]',
          'text=Changes saved',
        ];

        let isSaved = false;
        for (const ind of savedIndicators) {
          if (await page.locator(ind).first().isVisible({ timeout: 2000 }).catch(() => false)) {
            isSaved = true;
            log('✅', `Save confirmed — indicator: ${ind}`);
            break;
          }
        }

        if (isSaved) {
          await capture(page, 'save confirmed success', 'success');
          break;
        } else {
          log('⚠️', `Save confirmation not detected on attempt ${saveAttempts}`);
          await capture(page, `save attempt ${saveAttempts}`, 'info');
        }
      }

      if (!saveClicked) {
        await capture(page, 'save button not found', 'error');
        throw new Error('Save button not found on viz editor');
      }
    } catch (err) {
      await capture(page, 'save failed', 'error');
      log('❌', `Save failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // STEP 16  Click "Preview"
    // ──────────────────────────────────────────────────────
    console.log('\n══════════════════════════════════════════════');
    console.log('  STEP 16 — Click Preview Button (Top Right)');
    console.log('══════════════════════════════════════════════');
    try {
      const previewSelectors = [
        'button:has-text("Preview")',
        'a:has-text("Preview")',
        '[title*="preview" i]',
        '[aria-label*="preview" i]',
        '.btn-preview',
        '[class*="preview-btn"]',
        'input[value*="preview" i]',
        'button:has-text("Run")',
        'button:has-text("View")',
      ];

      let previewClicked = false;
      for (const sel of previewSelectors) {
        const el = page.locator(sel).first();
        if (await el.isVisible({ timeout: 3000 }).catch(() => false)) {
          await el.click();
          previewClicked = true;
          log('✅', `Preview clicked — selector: ${sel}`);
          break;
        }
      }

      if (!previewClicked) {
        await capture(page, 'preview button not found', 'error');
        throw new Error('Preview button not found');
      }

      await page.waitForLoadState('networkidle', { timeout: 25000 });
      await page.waitForTimeout(2500);

      // Confirm table data visible in preview
      const tableVisible = await page.locator(
        'table, [class*="table-preview"], [class*="data-table"], [class*="preview"] table'
      ).first().isVisible({ timeout: 8000 }).catch(() => false);

      if (tableVisible) {
        log('✅', 'Table visualization visible in preview');
        await capture(page, 'preview table viz displayed success', 'success');
      } else {
        log('⚠️', 'Table element not detected — screenshot taken');
        await capture(page, 'preview section opened', 'info');
      }
    } catch (err) {
      await capture(page, 'preview failed', 'error');
      log('❌', `Preview failed: ${err.message}`);
      throw err;
    }

    // ──────────────────────────────────────────────────────
    // FINAL
    // ──────────────────────────────────────────────────────
    await capture(page, 'test completed final state', 'success');

    console.log('\n╔══════════════════════════════════════════════╗');
    console.log('║   ✅  ALL 16 STEPS COMPLETED SUCCESSFULLY   ║');
    console.log('╚══════════════════════════════════════════════╝');
    console.log(`\n📁 Screenshots saved → ${SCREENSHOT_DIR}\n`);
  });
});
