# 🧪 AIV — Dashboard Table Visualization Test Scenario
### Automation: Playwright · App: `http://localhost:8080/aiv/`

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Prerequisites](#prerequisites)
3. [Setup & Installation](#setup--installation)
4. [Test Flow Diagram](#test-flow-diagram)
5. [Test Scenario — Step by Step](#test-scenario--step-by-step)
6. [Screenshot Index](#screenshot-index)
7. [Success & Error Message Reference](#success--error-message-reference)
8. [Troubleshooting Guide](#troubleshooting-guide)
9. [Running the Test](#running-the-test)

---

## Overview

This document describes the complete **Playwright end-to-end automation test** for creating a **Table Visualization** on the AIV Dashboard using the `global_cities_dataset`.

| Property | Detail |
|---|---|
| **App URL** | `http://localhost:8080/aiv/` |
| **Test File** | `aiv_dashboard_table_viz.spec.js` |
| **Framework** | Playwright (Node.js) |
| **Total Steps** | 16 |
| **Visualization Name** | `Test viz on Automation` |
| **Widget Type** | Table |
| **Dataset** | `global_cities_dataset` |
| **Columns** | All columns (via Select All checkbox) |

---

## Prerequisites

Ensure all of the following are met before running:

- ✅ **Node.js** v16 or higher installed
- ✅ **AIV application** running at `http://localhost:8080/aiv/`
- ✅ **Credentials** — Email: `Admin` · Password: `password`
- ✅ **Dataset** `global_cities_dataset` imported and available
- ✅ **Playwright** installed (`npm install @playwright/test`)
- ✅ **Chromium** installed (`npx playwright install chromium`)

---

## Setup & Installation

```bash
# 1. Create a project directory
mkdir aiv-playwright && cd aiv-playwright

# 2. Initialize Node.js
npm init -y

# 3. Install Playwright
npm install @playwright/test

# 4. Install browser binaries
npx playwright install chromium

# 5. Copy test file into project
cp aiv_dashboard_table_viz.spec.js ./
```

**Optional: `playwright.config.js`**
```js
// playwright.config.js
module.exports = {
  testDir: './',
  timeout: 120000,
  use: {
    headless: false,
    slowMo: 600,
    viewport: { width: 1440, height: 900 },
    video: 'on',
    screenshot: 'on',
  },
  reporter: [['list'], ['html']],
};
```

---

## Test Flow Diagram

```
  [Launch Browser]
       │
       ▼
  [Step 1] Open http://localhost:8080/aiv/
       │
       ▼
  [Step 2] Login — Email: Admin / Password: password
       │
       ▼
  [Step 3] Click Hamburger Menu (Top Left)
       │
       ▼
  [Step 4] Click "Dashboard" in Navigation
       │
       ▼
  [Step 5] Click "+" → Opens Create File Dialog
       │
       ▼
  [Step 6] Enter Name: "Test viz on Automation"
       │
       ▼
  [Step 7] Click "Create File" Button
       │
       ▼
  [Step 8] Viz Editor Opens (Widgets Panel Visible)
       │
       ▼
  [Step 9] Click "Table" Widget
       │  → Table viz added to left canvas
       ▼
  [Step 10] Click Home Icon → General Properties Panel
       │  → "Default" visible in Table settings
       ▼
  [Step 11] Click "Datasets" Section
       │
       ▼
  [Step 12] Search: "global_cities_dataset"
       │
       ▼
  [Step 13] Select "global_cities_dataset"
       │  → Available Columns appear at bottom
       ▼
  [Step 14] Check "Select All" Checkbox
       │  → All columns appear in Table viz (left panel)
       ▼
  [Step 15] Click Blue Save Icon (repeat until saved)
       │  → "Saved" confirmation message appears
       ▼
  [Step 16] Click Preview (Top Right)
       │
       ▼
  [RESULT] Table Visualization renders in Preview ✅
```

---

## Test Scenario — Step by Step

---

### 🔵 STEP 1 — Navigate to Application

| Field | Detail |
|---|---|
| **Action** | Open browser and navigate to `http://localhost:8080/aiv/` |
| **Wait For** | Page fully loaded (`networkidle`) |
| **Expected Result** | Login page is displayed |
| **Screenshot** | `01_success_application_loaded.png` |

**Console Messages:**
```
✅  Application loaded
📸 [SUCCESS] 01_success_application_loaded.png
```

**Error Scenario:**
```
❌  Application load failed: net::ERR_CONNECTION_REFUSED
📸 [ERROR] 01_error_application_load_failed.png

► Fix: Ensure AIV server is running → cd /path/to/aiv && ./start.sh
```

---

### 🔵 STEP 2 — Login

| Field | Detail |
|---|---|
| **Action** | Fill Email = `Admin`, Password = `password`, click Login |
| **Wait For** | Dashboard page loads after submit |
| **Expected Result** | User lands on the main dashboard / home page |
| **Screenshots** | `02_success_login_page_visible.png` · `03_info_credentials_filled.png` · `04_success_login_success_dashboard_loaded.png` |

**Console Messages:**
```
✅  Email field filled — "Admin"
✅  Password field filled
✅  Login submitted — waiting for dashboard
✅  Login successful
```

**Error Scenario:**
```
❌  Login failed: Timeout 25000ms exceeded
📸 [ERROR] 04_error_login_failed.png

► Possible causes:
    - Wrong credentials (Admin / password mismatch)
    - Login button selector changed in app
    - App not responding (check server logs)
```

---

### 🔵 STEP 3 — Click Hamburger Menu (Top Left)

| Field | Detail |
|---|---|
| **Action** | Click the hamburger / sidebar toggle icon at top-left of the screen |
| **Wait For** | Sidebar / navigation panel slides open |
| **Expected Result** | Navigation menu with Dashboard, Documents, etc. is visible |
| **Screenshot** | `05_success_hamburger_menu_opened.png` |

**Console Messages:**
```
✅  Hamburger clicked — selector: .hamburger
```

**Warning (non-fatal):**
```
⚠️  Hamburger clicked via coordinate fallback (28, 28)
    — Selenium-style selector did not match; used screen coordinates
```

**Error Scenario:**
```
❌  Hamburger failed: Element not interactable
► Fix: Check if a page overlay/modal is blocking the icon
```

---

### 🔵 STEP 4 — Navigate to Dashboard

| Field | Detail |
|---|---|
| **Action** | Click **Dashboard** in the navigation sidebar |
| **Wait For** | Dashboard section loads (`networkidle`) |
| **Expected Result** | Dashboard page with "+" add button is visible |
| **Screenshot** | `06_success_dashboard_section_opened.png` |

**Console Messages:**
```
✅  Dashboard nav clicked — selector: text=Dashboard
```

**Error Scenario:**
```
❌  Dashboard navigation item not found
📸 [ERROR] 06_error_dashboard_navigation_failed.png

► Possible causes:
    - Menu closed before step executed (hamburger state issue)
    - "Dashboard" label differs (e.g., "Dashboards", "Home")
    - User role does not have Dashboard access
```

---

### 🔵 STEP 5 — Click "+" to Create New Visualization

| Field | Detail |
|---|---|
| **Action** | Click the **+** (plus/add) icon button on the Dashboard page |
| **Wait For** | "Create File" modal / dialog appears |
| **Expected Result** | Create Visualization dialog box opens with a Name field |
| **Screenshot** | `07_success_create_viz_dialog_opened.png` |

**Console Messages:**
```
✅  "+" button clicked — selector: button:has-text("+")
```

**Error Scenario:**
```
❌  "+" / Create button not found on Dashboard
📸 [ERROR] 07_error_plus_button_failed.png

► Possible causes:
    - Icon uses SVG/img without text
    - Button has aria-label like "New Dashboard Item"
    - Dashboard page is still loading when step runs
► Fix: Increase page load wait time or inspect DOM for the button
```

---

### 🔵 STEP 6 — Enter Visualization Name

| Field | Detail |
|---|---|
| **Action** | Click the Name input field and type **`Test viz on Automation`** |
| **Wait For** | Text appears in input field |
| **Expected Result** | Name input shows: `Test viz on Automation` |
| **Screenshot** | `08_info_viz_name_entered.png` |

**Console Messages:**
```
✅  Name input found — selector: input[placeholder*="name" i]
✅  Viz name entered: "Test viz on Automation"
```

**Error Scenario:**
```
❌  Visualization name input field not found
📸 [ERROR] 08_error_viz_name_input_failed.png

► Possible causes:
    - Dialog has multiple text inputs; wrong one targeted
    - Dialog uses a custom rich-text field (not <input>)
► Fix: Inspect the modal HTML and update selector
```

---

### 🔵 STEP 7 — Click "Create File" Button

| Field | Detail |
|---|---|
| **Action** | Click the **Create File** (or Create / Submit) button in the dialog |
| **Wait For** | Success toast/banner + viz editor to load |
| **Expected Result** | ✅ `"Viz created successfully"` message appears; editor opens |
| **Screenshots** | `09_success_viz_created_success_message.png` · `10_info_after_create_file_click.png` |

**Console Messages:**
```
✅  "Create File" button clicked — selector: button:has-text("Create File")
✅  SUCCESS: Viz created successfully message appeared
```

**Warning:**
```
⚠️  Success toast not detected — checking if editor opened
    (Some AIV builds skip the toast and go directly to editor)
```

**Error Scenario:**
```
❌  "Create File" button not found
📸 [ERROR] 09_error_create_file_failed.png

► Possible causes:
    - Button text is "OK", "Confirm", or "New"
    - Form validation error blocking submission
    - Dialog dismissed on Enter keypress before button click
```

---

### 🔵 STEP 8 — Viz Editor Loaded

| Field | Detail |
|---|---|
| **Action** | Verify that the Visualization Editor is open |
| **Wait For** | Widgets panel is visible with chart/table options |
| **Expected Result** | Viz editor loads showing available widgets (Table, Chart, etc.) |
| **Screenshot** | `11_success_viz_editor_opened_with_widgets_panel.png` |

**Console Messages:**
```
✅  Viz editor detected — indicator: [class*="widget"]
```

**Warning (non-fatal):**
```
⚠️  Viz editor indicators not detected — screenshot taken for review
```

---

### 🔵 STEP 9 — Select "Table" Widget

| Field | Detail |
|---|---|
| **Action** | Click the **Table** widget from the widgets panel |
| **Wait For** | Table placeholder appears on the left canvas area |
| **Expected Result** | A blank Table visualization is added to the left canvas; Properties panel updates on the right |
| **Screenshot** | `12_success_table_widget_selected_added_to_canvas.png` |

**Console Messages:**
```
✅  Table widget clicked — selector: [class*="widget"]:has-text("Table")
```

**Error Scenario:**
```
❌  Table widget not found in the widgets panel
📸 [ERROR] 12_error_table_widget_selection_failed.png

► Possible causes:
    - Widget panel has not loaded yet
    - "Table" widget is inside a collapsed category/group
    - Widget labelled "Data Table" or "Grid" instead of "Table"
► Fix: Scroll through widget list, expand any groups, check labels
```

---

### 🔵 STEP 10 — Click Home Icon → General Properties

| Field | Detail |
|---|---|
| **Action** | Click the **Home / Default** icon in the right-side Properties panel |
| **Wait For** | General Properties section loads |
| **Expected Result** | Properties panel shows General settings with **Default** table layout selected |
| **Screenshot** | `13_success_general_properties_section_visible.png` |

**Console Messages:**
```
✅  Home / Default icon clicked — selector: i.fa-home
```

**Warning (non-fatal):**
```
⚠️  Home icon not found, may already be on General Properties
    (Step continues — non-fatal)
```

---

### 🔵 STEP 11 — Go to Datasets Section

| Field | Detail |
|---|---|
| **Action** | Click the **Datasets** tab/section in the properties or left panel |
| **Wait For** | Dataset search input and list become visible |
| **Expected Result** | Dataset search panel is open and ready for input |
| **Screenshot** | `14_success_datasets_section_open.png` |

**Console Messages:**
```
✅  Datasets tab clicked — selector: text=Datasets
```

**Warning (non-fatal):**
```
⚠️  Datasets tab not found — may already be visible in current panel
```

---

### 🔵 STEP 12 — Search for Dataset

| Field | Detail |
|---|---|
| **Action** | Type `global_cities_dataset` in the search box |
| **Wait For** | Filtered results appear in the dataset list |
| **Expected Result** | `global_cities_dataset` appears in the search results |
| **Screenshot** | `15_info_dataset_search_results_shown.png` |

**Console Messages:**
```
✅  Search input found — selector: input[placeholder*="search" i]
✅  Typed "global_cities_dataset" in search
```

**Warning (non-fatal):**
```
⚠️  Search input not found — trying direct selection from dropdown
    (Falls back to dropdown selection in Step 13)
```

---

### 🔵 STEP 13 — Select "global_cities_dataset"

| Field | Detail |
|---|---|
| **Action** | Click on **`global_cities_dataset`** in the search results or dropdown |
| **Wait For** | Available columns load at the bottom of the datasets panel |
| **Expected Result** | All columns of `global_cities_dataset` are listed (e.g., Country, City, Sales, Revenue, Population…) |
| **Screenshot** | `16_success_global_cities_dataset_selected_columns_visible.png` |

**Console Messages:**
```
✅  Dataset selected — selector: text=global_cities_dataset
```

**Error Scenario:**
```
❌  "global_cities_dataset" not found in dataset list
📸 [ERROR] 16_error_dataset_selection_failed.png

► Possible causes:
    - Dataset not imported into AIV
    - Dataset name is different (e.g., "GlobalCities", "cities_dataset")
    - Search returned no results (search bug)
► Fix: Import the dataset via AIV Admin → Datasets → Import
```

---

### 🔵 STEP 14 — Select All Columns (Checkbox)

| Field | Detail |
|---|---|
| **Action** | Click the **Select All** checkbox to enable all available columns |
| **Wait For** | All column names appear in the Table viz on the left canvas |
| **Expected Result** | Every column from `global_cities_dataset` is checked and renders in the Table widget preview |
| **Screenshot** | `17_success_all_columns_selected_visible_in_table_viz.png` |

**Console Messages:**
```
✅  "Select All" checkbox checked — selector: th input[type="checkbox"]
```

**Fallback behavior:**
```
⚠️  "Select All" not found — checking individual column checkboxes
ℹ️  Found 8 column checkboxes
✅  Checked all 8 column checkboxes individually
```

**Error Scenario:**
```
❌  Column selection failed: No checkboxes found
📸 [ERROR] 17_error_column_selection_failed.png

► Possible causes:
    - Dataset columns not yet loaded (slow network)
    - Columns rendered without checkbox UI (click-to-add style)
► Fix: Add explicit wait after dataset selection (waitForTimeout 3000)
```

---

### 🔵 STEP 15 — Click Blue Save Icon

| Field | Detail |
|---|---|
| **Action** | Click the **blue Save icon** (top of the editor toolbar). Retries up to **3 times** until confirmation is received |
| **Wait For** | Save success toast / "Saved" indicator appears |
| **Expected Result** | "Saved" or "Changes saved" message is displayed |
| **Screenshot** | `18_success_save_confirmed_success.png` |

**Console Messages:**
```
ℹ️  Save attempt 1 of 3
✅  Save button clicked — selector: button[title*="save" i]
✅  Save confirmed — indicator: text=Saved
```

**Warning (retry):**
```
⚠️  Save confirmation not detected on attempt 1
ℹ️  Save attempt 2 of 3
✅  Save confirmed — indicator: .toast-success
```

**Error Scenario:**
```
❌  Save button not found on viz editor
📸 [ERROR] 18_error_save_failed.png

► Possible causes:
    - Save icon is an image (not button/i element)
    - Unsaved changes lock is active
    - Editor not fully initialized
► Fix: Inspect the top toolbar for the blue save icon's HTML structure
```

---

### 🔵 STEP 16 — Click Preview

| Field | Detail |
|---|---|
| **Action** | Click the **Preview** button (top-right of viz editor) |
| **Wait For** | Preview section renders the Table visualization |
| **Expected Result** | Table showing all `global_cities_dataset` columns and rows is displayed in the Preview area |
| **Screenshot** | `19_success_preview_table_viz_displayed_success.png` |

**Console Messages:**
```
✅  Preview clicked — selector: button:has-text("Preview")
✅  Table visualization visible in preview
```

**Warning:**
```
⚠️  Table element not detected — screenshot taken
    (Data may still be loading; check screenshot manually)
```

**Error Scenario:**
```
❌  Preview failed: Preview button not found
📸 [ERROR] 19_error_preview_failed.png

► Possible causes:
    - Work not saved (save step failed silently)
    - Preview button inside a collapsed panel
    - Button labeled "Run", "View", or "Render"
► Fix: Ensure Step 15 (Save) completed, then re-run
```

---

## Screenshot Index

All screenshots are saved to `./screenshots_table_viz/` :

| # | File | Status | Step | Description |
|---|------|--------|------|-------------|
| 01 | `01_success_application_loaded.png` | ✅ | 1 | Login page shown |
| 02 | `02_success_login_page_visible.png` | ✅ | 2 | Login form loaded |
| 03 | `03_info_credentials_filled.png` | ℹ️ | 2 | Admin / password entered |
| 04 | `04_success_login_success_dashboard_loaded.png` | ✅ | 2 | Dashboard after login |
| 05 | `05_success_hamburger_menu_opened.png` | ✅ | 3 | Side nav open |
| 06 | `06_success_dashboard_section_opened.png` | ✅ | 4 | Dashboard page |
| 07 | `07_success_create_viz_dialog_opened.png` | ✅ | 5 | Create dialog open |
| 08 | `08_info_viz_name_entered.png` | ℹ️ | 6 | Name typed in field |
| 09 | `09_success_viz_created_success_message.png` | ✅ | 7 | "Created" toast shown |
| 10 | `10_info_after_create_file_click.png` | ℹ️ | 7 | Post-create state |
| 11 | `11_success_viz_editor_opened_with_widgets_panel.png` | ✅ | 8 | Editor with widgets |
| 12 | `12_success_table_widget_selected_added_to_canvas.png` | ✅ | 9 | Table on canvas |
| 13 | `13_success_general_properties_section_visible.png` | ✅ | 10 | Properties panel |
| 14 | `14_success_datasets_section_open.png` | ✅ | 11 | Dataset panel open |
| 15 | `15_info_dataset_search_results_shown.png` | ℹ️ | 12 | Search results |
| 16 | `16_success_global_cities_dataset_selected_columns_visible.png` | ✅ | 13 | Columns listed |
| 17 | `17_success_all_columns_selected_visible_in_table_viz.png` | ✅ | 14 | All columns in table |
| 18 | `18_success_save_confirmed_success.png` | ✅ | 15 | Save toast |
| 19 | `19_success_preview_table_viz_displayed_success.png` | ✅ | 16 | Table in preview |
| 20 | `20_success_test_completed_final_state.png` | ✅ | — | Final state |

> ❌ **Error screenshots** follow the same numbering with `_error_` in the filename.
> e.g., `07_error_plus_button_failed.png`

---

## Success & Error Message Reference

### ✅ Complete Success Output

```
══════════════════════════════════════════════
  STEP 1 — Navigate to Application
══════════════════════════════════════════════
✅  Application loaded
📸 [SUCCESS] 01_success_application_loaded.png

══════════════════════════════════════════════
  STEP 2 — Login
══════════════════════════════════════════════
✅  Email field filled — "Admin"
✅  Password field filled
✅  Login submitted — waiting for dashboard
📸 [INFO] 03_info_credentials_filled.png
✅  Login successful
📸 [SUCCESS] 04_success_login_success_dashboard_loaded.png

══════════════════════════════════════════════
  STEP 3 — Click Hamburger Menu (Top Left)
══════════════════════════════════════════════
✅  Hamburger clicked — selector: .hamburger
📸 [SUCCESS] 05_success_hamburger_menu_opened.png

══════════════════════════════════════════════
  STEP 4 — Navigate to Dashboard
══════════════════════════════════════════════
✅  Dashboard nav clicked — selector: text=Dashboard
📸 [SUCCESS] 06_success_dashboard_section_opened.png

══════════════════════════════════════════════
  STEP 5 — Click "+" to Create New Visualization
══════════════════════════════════════════════
✅  "+" button clicked — selector: button:has-text("+")
📸 [SUCCESS] 07_success_create_viz_dialog_opened.png

══════════════════════════════════════════════
  STEP 6 — Enter Visualization Name
══════════════════════════════════════════════
✅  Name input found — selector: input[placeholder*="name" i]
✅  Viz name entered: "Test viz on Automation"
📸 [INFO] 08_info_viz_name_entered.png

══════════════════════════════════════════════
  STEP 7 — Click "Create File" Button
══════════════════════════════════════════════
✅  "Create File" button clicked — selector: button:has-text("Create File")
✅  SUCCESS: Viz created successfully message appeared
📸 [SUCCESS] 09_success_viz_created_success_message.png

══════════════════════════════════════════════
  STEP 8 — Viz Editor Loaded
══════════════════════════════════════════════
✅  Viz editor detected — indicator: [class*="widget"]
📸 [SUCCESS] 11_success_viz_editor_opened_with_widgets_panel.png

══════════════════════════════════════════════
  STEP 9 — Select "Table" Widget
══════════════════════════════════════════════
✅  Table widget clicked — selector: [class*="widget"]:has-text("Table")
📸 [SUCCESS] 12_success_table_widget_selected_added_to_canvas.png

══════════════════════════════════════════════
  STEP 10 — Click Home Icon → General Properties
══════════════════════════════════════════════
✅  Home / Default icon clicked — selector: i.fa-home
📸 [SUCCESS] 13_success_general_properties_section_visible.png

══════════════════════════════════════════════
  STEP 11 — Go to Datasets Section
══════════════════════════════════════════════
✅  Datasets tab clicked — selector: text=Datasets
📸 [SUCCESS] 14_success_datasets_section_open.png

══════════════════════════════════════════════
  STEP 12 — Search Dataset: global_cities_dataset
══════════════════════════════════════════════
✅  Search input found — selector: input[placeholder*="search" i]
✅  Typed "global_cities_dataset" in search
📸 [INFO] 15_info_dataset_search_results_shown.png

══════════════════════════════════════════════
  STEP 13 — Select global_cities_dataset
══════════════════════════════════════════════
✅  Dataset selected — selector: text=global_cities_dataset
📸 [SUCCESS] 16_success_global_cities_dataset_selected_columns_visible.png

══════════════════════════════════════════════
  STEP 14 — Select All Columns (Checkbox)
══════════════════════════════════════════════
✅  "Select All" checkbox checked — selector: th input[type="checkbox"]
📸 [SUCCESS] 17_success_all_columns_selected_visible_in_table_viz.png

══════════════════════════════════════════════
  STEP 15 — Save the Work (Blue Save Icon)
══════════════════════════════════════════════
ℹ️  Save attempt 1 of 3
✅  Save button clicked — selector: button[title*="save" i]
✅  Save confirmed — indicator: text=Saved
📸 [SUCCESS] 18_success_save_confirmed_success.png

══════════════════════════════════════════════
  STEP 16 — Click Preview Button (Top Right)
══════════════════════════════════════════════
✅  Preview clicked — selector: button:has-text("Preview")
✅  Table visualization visible in preview
📸 [SUCCESS] 19_success_preview_table_viz_displayed_success.png

╔══════════════════════════════════════════════╗
║   ✅  ALL 16 STEPS COMPLETED SUCCESSFULLY   ║
╚══════════════════════════════════════════════╝

📁 Screenshots saved → ./screenshots_table_viz/
```

---

### ❌ Common Errors & Fixes

| Error Message | Likely Cause | Fix |
|---|---|---|
| `net::ERR_CONNECTION_REFUSED` | Server not running | Start AIV on port 8080 |
| `Login failed: Timeout exceeded` | Wrong credentials or page slow | Verify `Admin`/`password`; increase timeout |
| `Dashboard navigation item not found` | Menu not open or text differs | Check hamburger step; inspect sidebar HTML |
| `"+" / Create button not found` | Icon-only button (no text) | Inspect DOM; add `aria-label` selector |
| `Visualization name input field not found` | Modal structure differs | Inspect dialog for input element |
| `"Create File" button not found` | Button text differs | Check for "OK", "Confirm", "New" buttons |
| `Table widget not found in the widgets panel` | Widget in collapsed group | Expand widget categories; scroll panel |
| `"global_cities_dataset" not found in list` | Dataset not imported | Import via Admin → Datasets section |
| `No checkboxes found` | Columns rendered as click-to-add | Inspect column list HTML structure |
| `Save button not found` | Save icon is an `<img>` tag | Inspect toolbar; target `img[alt*="save"]` |
| `Preview failed: button not found` | Save never completed | Ensure Step 15 succeeded first |

---

## Troubleshooting Guide

### 🔧 Select2 or Custom Dropdown for Dataset

If the dataset field is a Select2 component:

```js
// Open the Select2 container
await page.locator('.select2-container').click();

// Type in the search box that appears
await page.locator('.select2-search__field').fill('global_cities_dataset');
await page.waitForTimeout(500);

// Click the matching option
await page.locator('.select2-results__option:has-text("global_cities_dataset")').click();
```

---

### 🔧 Save Icon is an Image (not a button)

```js
// If save icon is <img alt="Save">
await page.locator('img[alt*="save" i]').first().click();

// If it's an SVG with title
await page.locator('svg title:has-text("Save")').locator('..').click();
```

---

### 🔧 Column Checkboxes use Click-to-Add (no checkbox)

```js
// If columns are toggled by clicking a label/row
const columns = page.locator('[class*="available-column"], [class*="column-item"]');
const count = await columns.count();
for (let i = 0; i < count; i++) {
  await columns.nth(i).click();
  await page.waitForTimeout(200);
}
```

---

### 🔧 Viz Editor in iFrame

If the editor is inside an `<iframe>`:

```js
const editorFrame = page.frameLocator('iframe[src*="editor"], iframe#viz-frame');
// Then use editorFrame instead of page
await editorFrame.locator('[class*="widget"]:has-text("Table")').click();
```

---

### 🔧 Increasing Timeouts for Slow Environments

```js
// At the top of the test:
test.setTimeout(180000); // 3 minutes total

// For individual waits:
await page.waitForLoadState('networkidle', { timeout: 45000 });
await page.waitForTimeout(3000); // longer settle time
```

---

## Running the Test

```bash
# Run with browser visible (recommended)
npx playwright test aiv_dashboard_table_viz.spec.js --headed

# Run headless
npx playwright test aiv_dashboard_table_viz.spec.js

# Verbose console output
npx playwright test aiv_dashboard_table_viz.spec.js --reporter=list

# Generate and open HTML report
npx playwright test aiv_dashboard_table_viz.spec.js --reporter=html
npx playwright show-report

# Run only this test file
npx playwright test aiv_dashboard_table_viz.spec.js --project=chromium
```

---

### 📁 Output Files After Successful Run

```
screenshots_table_viz/
  01_success_application_loaded.png
  02_success_login_page_visible.png
  03_info_credentials_filled.png
  04_success_login_success_dashboard_loaded.png
  05_success_hamburger_menu_opened.png
  06_success_dashboard_section_opened.png
  07_success_create_viz_dialog_opened.png
  08_info_viz_name_entered.png
  09_success_viz_created_success_message.png
  10_info_after_create_file_click.png
  11_success_viz_editor_opened_with_widgets_panel.png
  12_success_table_widget_selected_added_to_canvas.png
  13_success_general_properties_section_visible.png
  14_success_datasets_section_open.png
  15_info_dataset_search_results_shown.png
  16_success_global_cities_dataset_selected_columns_visible.png
  17_success_all_columns_selected_visible_in_table_viz.png
  18_success_save_confirmed_success.png
  19_success_preview_table_viz_displayed_success.png
  20_success_test_completed_final_state.png

test-results/
  video.webm           ← Full screen recording of test

playwright-report/
  index.html           ← Detailed HTML test report
```

---

## Notes

- The test uses **multiple selector fallbacks** at each step to handle UI variations across AIV builds
- **Non-fatal steps** (Home icon, Datasets tab) continue the test with a warning if not found
- Screenshot filenames include `success_`, `error_`, or `info_` prefix for easy filtering
- **Save step retries up to 3 times** to ensure the work is persisted before Preview
- **Video recording** is on by default — check `test-results/` for `.webm` replay
- All selector lists are ordered from most specific → most generic as fallback chains

---

*Generated for AIV Application · Dashboard Table Visualization · Playwright Automation Suite*
